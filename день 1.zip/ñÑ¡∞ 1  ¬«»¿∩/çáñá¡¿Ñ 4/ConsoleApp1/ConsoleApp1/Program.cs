﻿using System; 

class Program 
{
    static void Main() 
    {
        Random rand = new Random(); // создается объект для генерации случайных чисел
        int[] numbers = new int[15]; // создается массив из 15 элементов
        for (int i = 0; i < numbers.Length; i++) // заполнение массива случайными числами
        {
            numbers[i] = rand.Next(-50, 51); // генерирация числа от -50 до 50
        }
        Console.WriteLine("Сгенерированный массив: " + string.Join(" ", numbers)); // вывод массива
        double sum = 0; // переменная для суммы положительных чисел
        int count = 0; // счетчик положительных чисел
        foreach (int num in numbers) // проходим по массиву
        {
            if (num > 0) // проверка, является ли число положительным
            {
                sum += num; // добавляем к сумме
                count++; // увеличиваем счетчик
            }
        }
        if (count == 0) // проверка, есть ли положительные числа
        {
            Console.WriteLine("Положительные числа отсутствуют"); // вывод сообщения, если положительных чисел нет
        }
        else
        {
            double average = sum / count; // вычисляем среднее значение
            Console.WriteLine($"Среднее значение положительных чисел: {average:F2}"); 
        }
    }
}