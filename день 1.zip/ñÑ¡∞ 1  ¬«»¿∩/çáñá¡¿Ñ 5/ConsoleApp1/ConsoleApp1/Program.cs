﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите число: "); // запрос числа у пользователя
        if (!int.TryParse(Console.ReadLine(), out int n)) // проверка, является ли ввод целым числом
        {
            Console.WriteLine("Ошибка: введите целое число"); // вывод ошибки при некорректном вводе
            return;
        }
        if (n <= 1) // проверка, меньше ли число 2 (0 и 1 не простые)
        {
            Console.WriteLine($"{n} не является простым числом"); // вывод результата для чисел <= 1
            return;
        }
        bool isPrime = IsPrime(n); // проверка, является ли число простым
        Console.WriteLine(isPrime ? $"{n} является простым числом" : $"{n} не является простым числом");

        static bool IsPrime(int n) // метод для проверки, является ли число простым
        {
            for (int i = 2; i <= Math.Sqrt(n); i++) // проверка делителей от 2 до корня из n
            {
                if (n % i == 0) return false; // если найден делитель, число не простое
            }
            return true; // если делителей нет, число простое
        }
    }
}